import { useState } from 'react';
import { AlertCircle, Bell, MapPin, Zap } from 'lucide-react';
import AppNavigation from '@/components/AppNavigation';
import DonationMap from '@/components/DonationMap';
import DonorDashboard from '@/components/DonorDashboard';

export default function Home() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomeTab />;
      case 'appointments':
        return <AppointmentsTab />;
      case 'donate':
        return <DonateTab />;
      case 'community':
        return <CommunityTab />;
      case 'profile':
        return <DonorDashboard />;
      default:
        return <HomeTab />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row pb-20 md:pb-0">
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <div className="p-4 md:p-8 max-w-6xl mx-auto">
          {renderContent()}
        </div>
      </main>

      {/* Navigation */}
      <AppNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

function HomeTab() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg p-8 shadow-lg">
        <h1 className="text-4xl font-bold mb-2">DoeVida</h1>
        <p className="text-red-100 text-lg">Conectando doadores e centros de coleta para salvar vidas</p>
      </div>

      {/* Alert Banner */}
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-lg">
        <div className="flex items-start gap-3">
          <AlertCircle className="text-yellow-600 flex-shrink-0 mt-0.5" size={20} />
          <div>
            <h3 className="font-semibold text-yellow-800">Alerta de Estoque Crítico</h3>
            <p className="text-yellow-700 text-sm mt-1">Tipo O- urgentemente necessário no Hemocentro Coordenador (1.8 km)</p>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-700">Centros em Goiânia</h3>
            <MapPin className="text-red-600" size={20} />
          </div>
          <p className="text-3xl font-bold text-slate-900">3</p>
          <p className="text-sm text-slate-600 mt-1">Hemocentros ativos</p>
        </div>

        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-700">Estoques Críticos</h3>
            <Zap className="text-yellow-600" size={20} />
          </div>
          <p className="text-3xl font-bold text-slate-900">3</p>
          <p className="text-sm text-slate-600 mt-1">Tipos sanguíneos urgentes</p>
        </div>

        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-700">Notificações</h3>
            <Bell className="text-blue-600" size={20} />
          </div>
          <p className="text-3xl font-bold text-slate-900">2</p>
          <p className="text-sm text-slate-600 mt-1">Novas mensagens</p>
        </div>
      </div>

      {/* Map Section */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-4">Centros de Coleta Próximos</h2>
        <DonationMap />
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:border-red-600 transition-colors">
          <h3 className="text-lg font-bold text-slate-900 mb-3">🗺️ Mapa Interativo</h3>
          <p className="text-slate-600">Localize centros de coleta próximos e veja estoques em tempo real</p>
        </div>
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:border-red-600 transition-colors">
          <h3 className="text-lg font-bold text-slate-900 mb-3">📅 Agendamento Fácil</h3>
          <p className="text-slate-600">Reserve seu horário e evite filas nos centros de coleta</p>
        </div>
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:border-red-600 transition-colors">
          <h3 className="text-lg font-bold text-slate-900 mb-3">🎖️ Gamificação</h3>
          <p className="text-slate-600">Ganhe medalhas e reconhecimento por suas coletas</p>
        </div>
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:border-red-600 transition-colors">
          <h3 className="text-lg font-bold text-slate-900 mb-3">🔔 Alertas Inteligentes</h3>
          <p className="text-slate-600">Receba notificações quando seu tipo sanguíneo é urgente</p>
        </div>
      </div>
    </div>
  );
}

function AppointmentsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-slate-900">Meus Agendamentos</h2>
      <div className="bg-white border-2 border-slate-200 rounded-lg p-8 text-center">
        <p className="text-slate-600 mb-4">Você não possui agendamentos no momento</p>
        <button className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors">
          Agendar Coleta
        </button>
      </div>
    </div>
  );
}

function DonateTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-slate-900">Processo de Coleta</h2>
      <div className="space-y-4">
        {[
          { step: 1, title: 'Triagem', desc: 'Verificação de saúde e histórico médico' },
          { step: 2, title: 'Coleta', desc: 'Coleta segura de 450ml de sangue' },
          { step: 3, title: 'Repouso', desc: 'Período de repouso de 15 minutos' },
          { step: 4, title: 'Lanche', desc: 'Oferecimento de lanches e bebidas' },
        ].map((item) => (
          <div key={item.step} className="bg-white border-2 border-slate-200 rounded-lg p-6 flex items-start gap-4">
            <div className="w-12 h-12 bg-red-600 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
              {item.step}
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{item.title}</h3>
              <p className="text-slate-600 text-sm mt-1">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CommunityTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-slate-900">Comunidade de Doadores</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          { name: 'Maria Silva', donations: 25, status: 'Herói Local' },
          { name: 'Carlos Santos', donations: 18, status: 'Doador Ativo' },
          { name: 'Ana Costa', donations: 12, status: 'Doador Dedicado' },
          { name: 'Pedro Oliveira', donations: 8, status: 'Novo Doador' },
        ].map((donor, idx) => (
          <div key={idx} className="bg-white border-2 border-slate-200 rounded-lg p-6">
            <h3 className="font-bold text-slate-900">{donor.name}</h3>
            <p className="text-sm text-slate-600 mt-1">{donor.donations} doações</p>
            <span className="inline-block mt-3 px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-full">
              {donor.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
