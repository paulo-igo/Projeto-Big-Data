import { Heart, Calendar, Droplet, Award, TrendingUp } from 'lucide-react';

interface DonationRecord {
  date: string;
  center: string;
  volume: string;
}

interface DonorProfile {
  name: string;
  bloodType: string;
  totalDonations: number;
  lastDonation: string;
  nextEligible: string;
  status: 'eligible' | 'waiting' | 'ineligible';
  donationRecords: DonationRecord[];
}

const mockDonor: DonorProfile = {
  name: 'João Silva',
  bloodType: 'O+',
  totalDonations: 12,
  lastDonation: '15 de janeiro de 2026',
  nextEligible: '15 de fevereiro de 2026',
  status: 'waiting',
  donationRecords: [
    { date: '15/01/2026', center: 'Hemocentro Coordenador Estadual', volume: '450ml' },
    { date: '15/12/2025', center: 'Hemocentro Anhanguera', volume: '450ml' },
    { date: '15/11/2025', center: 'Hospital Araújo Jorge', volume: '450ml' },
  ]
};

export default function DonorDashboard() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'eligible':
        return { bg: 'bg-green-100', text: 'text-green-800', label: 'Pronto para Doar' };
      case 'waiting':
        return { bg: 'bg-yellow-100', text: 'text-yellow-800', label: 'Aguardando Período' };
      default:
        return { bg: 'bg-red-100', text: 'text-red-800', label: 'Inelevível' };
    }
  };

  const status = getStatusColor(mockDonor.status);
  const daysUntilEligible = Math.ceil((new Date(mockDonor.nextEligible).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));

  return (
    <div className="w-full space-y-6">
      {/* Header Card */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg p-8 shadow-lg">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold mb-2">{mockDonor.name}</h2>
            <p className="text-red-100">Tipo Sanguíneo: <span className="font-bold text-lg">{mockDonor.bloodType}</span></p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-full p-4">
            <Heart size={32} />
          </div>
        </div>
        
        <div className={`inline-block px-4 py-2 rounded-full font-semibold ${status.bg} ${status.text}`}>
          {status.label}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Total Donations */}
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:border-red-600 transition-colors">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-700 font-semibold">Total de Doações</h3>
            <Droplet className="text-red-600" size={24} />
          </div>
          <p className="text-4xl font-bold text-slate-900">{mockDonor.totalDonations}</p>
          <p className="text-sm text-slate-600 mt-2">Vidas potencialmente salvas: {mockDonor.totalDonations * 3}</p>
        </div>

        {/* Last Donation */}
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:border-red-600 transition-colors">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-700 font-semibold">Última Doação</h3>
            <Calendar className="text-blue-600" size={24} />
          </div>
          <p className="text-2xl font-bold text-slate-900">{mockDonor.lastDonation}</p>
          <p className="text-sm text-slate-600 mt-2">Há 17 dias</p>
        </div>

        {/* Next Eligible */}
        <div className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:border-red-600 transition-colors">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-700 font-semibold">Próxima Coleta</h3>
            <TrendingUp className="text-green-600" size={24} />
          </div>
          <p className="text-2xl font-bold text-slate-900">{daysUntilEligible} dias</p>
          <p className="text-sm text-slate-600 mt-2">{mockDonor.nextEligible}</p>
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white border-2 border-slate-200 rounded-lg p-6">
        <div className="flex items-center gap-2 mb-4">
          <Award className="text-yellow-600" size={24} />
          <h3 className="text-lg font-bold text-slate-900">Conquistas</h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Primeiro Passo', icon: '🩸' },
            { label: '5 Coletas', icon: '⭐' },
            { label: '10 Coletas', icon: '🏆' },
            { label: 'Herói Local', icon: '🦸' }
          ].map((achievement, idx) => (
            <div key={idx} className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-4 text-center border border-yellow-200">
              <div className="text-3xl mb-2">{achievement.icon}</div>
              <p className="text-sm font-semibold text-slate-800">{achievement.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Donation History */}
      <div className="bg-white border-2 border-slate-200 rounded-lg p-6">
        <h3 className="text-lg font-bold text-slate-900 mb-4">Histórico de Coletas</h3>
        <div className="space-y-3">
          {mockDonor.donationRecords.map((record, idx) => (
            <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200 hover:bg-slate-100 transition-colors">
              <div>
                <p className="font-semibold text-slate-900">{record.date}</p>
                <p className="text-sm text-slate-600">{record.center}</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-red-600">{record.volume}</p>
                <p className="text-xs text-slate-600">Coletado</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      {mockDonor.status === 'eligible' && (
        <button className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-4 rounded-lg transition-all shadow-lg hover:shadow-xl">
          Agendar Coleta Agora
        </button>
      )}
    </div>
  );
}
