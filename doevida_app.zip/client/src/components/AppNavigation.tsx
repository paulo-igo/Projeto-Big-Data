import { Home, Calendar, Droplet, Users, User } from 'lucide-react';
import { useState } from 'react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
}

const navItems: NavItem[] = [
  { id: 'home', label: 'Início', icon: <Home size={24} /> },
  { id: 'appointments', label: 'Agendamentos', icon: <Calendar size={24} /> },
  { id: 'donate', label: 'Coletar', icon: <Droplet size={24} /> },
  { id: 'community', label: 'Comunidade', icon: <Users size={24} /> },
  { id: 'profile', label: 'Perfil', icon: <User size={24} /> },
];

interface AppNavigationProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

export default function AppNavigation({ activeTab, onTabChange }: AppNavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-slate-200 shadow-2xl md:relative md:bottom-auto md:border-t-0 md:border-r-2 md:w-20 md:h-screen md:flex md:flex-col md:items-center md:py-6 md:gap-6">
      <div className="flex justify-around w-full md:flex-col md:gap-6">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center justify-center py-3 px-4 md:p-4 transition-all rounded-lg ${
              activeTab === item.id
                ? 'text-red-600 bg-red-50 md:bg-red-100'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
            title={item.label}
          >
            {item.icon}
            <span className="text-xs mt-1 md:hidden">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
