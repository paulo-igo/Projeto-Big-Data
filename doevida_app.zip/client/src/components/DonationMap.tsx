import { MapPin, AlertCircle, Clock, Users } from 'lucide-react';
import { useState } from 'react';

interface DonationCenter {
  id: string;
  name: string;
  address: string;
  distance: number;
  urgency: 'critical' | 'warning' | 'normal';
  bloodTypes: string[];
  hours: string;
  available: number;
}

const mockCenters: DonationCenter[] = [
  {
    id: '1',
    name: 'Hemocentro Coordenador Estadual',
    address: 'Av. Anhanguera, 7.323 - Setor Coimbra, Goiânia',
    distance: 1.8,
    urgency: 'critical',
    bloodTypes: ['O-', 'O+', 'A-'],
    hours: '08:00 - 18:00 (Seg-Sex)',
    available: 4
  },
  {
    id: '2',
    name: 'Hemocentro Anhanguera',
    address: 'Av. Anhanguera, 5.195 - Setor Oeste, Goiânia',
    distance: 3.2,
    urgency: 'warning',
    bloodTypes: ['B+', 'AB+', 'A+'],
    hours: '08:00 - 18:00 (Seg-Sex)',
    available: 7
  },
  {
    id: '3',
    name: 'Hospital Araújo Jorge - Banco de Sangue',
    address: 'Rua 239, 196 - Setor Universitário, Goiânia',
    distance: 5.4,
    urgency: 'normal',
    bloodTypes: ['O+', 'A+', 'B+', 'AB+'],
    hours: '07:00 - 17:00 (Seg-Sex)',
    available: 12
  },
];

export default function DonationMap() {
  const [selectedCenter, setSelectedCenter] = useState<DonationCenter | null>(null);

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical':
        return 'bg-red-600 text-white';
      case 'warning':
        return 'bg-yellow-500 text-white';
      default:
        return 'bg-green-600 text-white';
    }
  };

  const getUrgencyBadge = (urgency: string) => {
    switch (urgency) {
      case 'critical':
        return { label: 'Urgente', icon: AlertCircle };
      case 'warning':
        return { label: 'Alerta', icon: Clock };
      default:
        return { label: 'Normal', icon: Users };
    }
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg overflow-hidden shadow-lg">
      {/* Map Container */}
      <div className="relative w-full h-96 bg-slate-200 flex items-center justify-center overflow-hidden">
        <img 
          src="/images/goiania-map.jpg" 
          alt="Mapa de Centros de Coleta de Goiânia" 
          className="w-full h-full object-cover"
        />
        
        {/* Location Pins */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative w-full h-full">
            {mockCenters.map((center, idx) => (
              <button
                key={center.id}
                onClick={() => setSelectedCenter(center)}
                className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-200 hover:scale-125 ${
                  selectedCenter?.id === center.id ? 'scale-125 z-20' : 'z-10'
                }`}
                style={{
                  left: `${25 + idx * 25}%`,
                  top: `${40 + idx * 15}%`
                }}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg ${getUrgencyColor(center.urgency)}`}>
                  <MapPin size={20} />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Center List */}
      <div className="p-6 space-y-4">
        <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <MapPin size={24} className="text-red-600" />
          Centros de Coleta Próximos
        </h3>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {mockCenters.map((center) => {
            const urgency = getUrgencyBadge(center.urgency);
            const UrgencyIcon = urgency.icon;
            
            return (
              <button
                key={center.id}
                onClick={() => setSelectedCenter(center)}
                className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                  selectedCenter?.id === center.id
                    ? 'border-red-600 bg-red-50'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-semibold text-slate-900">{center.name}</h4>
                    <p className="text-sm text-slate-600">{center.address}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 ${getUrgencyColor(center.urgency)}`}>
                    <UrgencyIcon size={14} />
                    {urgency.label}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div className="flex items-center gap-2 text-slate-700">
                    <MapPin size={16} className="text-slate-500" />
                    <span>{center.distance} km</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Clock size={16} className="text-slate-500" />
                    <span>{center.hours}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Users size={16} className="text-slate-500" />
                    <span>{center.available} vagas</span>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  {center.bloodTypes.map((type) => (
                    <span
                      key={type}
                      className="px-2 py-1 bg-slate-100 text-slate-700 text-xs font-semibold rounded border border-slate-300"
                    >
                      {type}
                    </span>
                  ))}
                </div>

                {selectedCenter?.id === center.id && (
                  <button className="w-full mt-4 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 rounded-lg transition-colors">
                    Agendar Coleta
                  </button>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
